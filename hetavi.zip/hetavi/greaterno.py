a=int(input("enter the first no:"))
b=int(input("enter the second no:"))
c=int(input("enter the Third no:"))
if a>b:
    if a>c:
        print("a is greater:")
    else:
        print("c is greater")
else:
    if b>a:
        print("b is greater:")
    else:
        print("c is is greater:")   
