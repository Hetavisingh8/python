a="abcdefg"
b="hkijyl"
print(a)
print(b)
temp=a
a=b
b=temp
print(a,b)

