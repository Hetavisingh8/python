'''age=int(input("enter the no:"))
if age>18 and age<60:
    print("Eligible")
elif age>60:
    print("senior")
else:
    print("not eligible")
'''
'''
if 0:
    print("hetavi")
else:
    print("ragini")
'''
'''
a=int(input("enter the no:"))
if a%5==0:
      print("divisible")
else:
    print("not divisible")
'''
'''
i=1
while i<=10:
    if i==4:break
    print(i)
    i=i+1
    '''
h="hetavi singh"
print(h.lower())
print(h.count(
