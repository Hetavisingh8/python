a=int(input("enter the no"))
if a==0:
    print("number is zero")
elif a%2==0:
    print("number is even:")
else:
    print("number is odd:")
    
